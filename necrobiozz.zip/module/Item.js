export default class NecrobiozzItem extends Item {
  async roll() {
  }
}
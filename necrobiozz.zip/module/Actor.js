export default class NecrobiozzActor extends Actor {
  prepareData() {
    super.prepareData();
  }
}